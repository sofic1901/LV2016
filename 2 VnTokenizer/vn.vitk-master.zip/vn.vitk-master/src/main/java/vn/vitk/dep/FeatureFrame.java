package vn.vitk.dep;

/**
 * @author Phuong Le-Hong <phuonglh@gmail.com>
 * <p>Jan 30, 2016, 10:16:09 AM
 * <p>
 * Some predefined feature frames.
 */
public enum FeatureFrame {
	TAG,
	TAG_TOKEN,
	TAG_TOKEN_TYPE,
}
