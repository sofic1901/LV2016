package vn.vitk.tag;


/**
 * @author Phuong LE-HONG
 * <p>
 * May 11, 2016, 5:53:37 PM
 * <p>
 * Markov order type, up the third order.
 */
public enum MarkovOrder {
	FIRST, SECOND, THIRD
}
