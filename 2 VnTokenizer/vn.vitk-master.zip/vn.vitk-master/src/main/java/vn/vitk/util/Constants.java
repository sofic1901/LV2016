package vn.vitk.util;

/**
 * @author Phuong LE-HONG
 * <p>
 * May 27, 2016, 6:23:17 PM
 * <p>
 * Some predefined constants used in the toolkit. 
 */
public interface Constants {
	public static final String REGEXP_FILE = "/export/dat/tok/regexp.txt";
}
