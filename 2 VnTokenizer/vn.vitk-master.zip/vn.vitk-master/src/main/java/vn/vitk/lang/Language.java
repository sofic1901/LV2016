package vn.vitk.lang;

public enum Language {
	ENGLISH,
	VIETNAMESE
}
